let handler = async (m, { conn }) => {
m.reply(global.destraba)
m.reply(global.destraba)
}
handler.command = /^(destraba|deztraba|clear)$/i
export default handler
