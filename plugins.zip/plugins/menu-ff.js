let handler = async(m, { isOwner, isAdmin, conn, text, participants, args, command }) => {
if (!(isAdmin || isOwner)) {
global.dfail('admin', m, conn)
throw false
}
let pesan = args.join` `
let oi = `ANOTENSE MANCOS CULIAOS🔥 ${pesan}`
let teks = `╭┈┈ ๑👻๑ •• ${oi} ๑👻๑ ••:\n`
for (let mem of participants) {
teks += `ㅤ *⌜ 𝙈𝙀𝙉𝙐 𝘿𝙀 𝙑𝙀𝙍𝙎𝙐𝙎 ⌟*
━━━━━━━━━━━━━━━━━━━
☁️ 𝗥𝗘𝗚𝗜𝗢𝗡 𝗦𝗨𝗥 ( 𝗩𝗜𝗩𝗜𝗗𝗢 )
━━━━━━━━━━━━━━━━━━━
⊹ *${usedPrefix}4vs4a1*
⊹ *${usedPrefix}4vs4a2*
⊹ *${usedPrefix}4vs4a3*
⊹ *${usedPrefix}4vs4a4*
⊹ *${usedPrefix}4vs4a5*
⊹ *${usedPrefix}4vs4a6*
━━━━━━━━━━━━━━━━━━━
☁️ 𝗥𝗘𝗚𝗜𝗢𝗡 𝗦𝗨𝗥 ( 𝗜𝗡𝗙𝗜𝗡𝗜𝗧𝗢 )
━━━━━━━━━━━━━━━━━━━
⊹ *${usedPrefix}4vs4b1*
⊹ *${usedPrefix}4vs4b2*
⊹ *${usedPrefix}4vs4b3*
⊹ *${usedPrefix}4vs4b4*
⊹ *${usedPrefix}4vs4b5*
━━━━━━━━━━━━━━━━━━━
⭐ 𝗥𝗘𝗚𝗜𝗢𝗡 𝗡𝗢𝗥𝗧𝗘 (  )
━━━━━━━━━━━━━━━━━━━
⊹ *${usedPrefix}4vs4n1*
⊹ *${usedPrefix}4vs4n2*
⊹ *${usedPrefix}4vs4n3*
⊹ *${usedPrefix}4vs4n4*
⊹ *${usedPrefix}4vs4n5*
⊹ *${usedPrefix}4vs4n6*
━━━━━━━━━━━━━━━━━━━
⭐ 𝗥𝗘𝗚𝗜𝗢𝗡 𝗡𝗢𝗥𝗧𝗘 ( 𝗜𝗡𝗙𝗜𝗡𝗜𝗧𝗢 )
━━━━━━━━━━━━━━━━━━━
⊹ *${usedPrefix}4vs4d1*
⊹ *${usedPrefix}4vs4d2*
⊹ *${usedPrefix}4vs4d3*
⊹ *${usedPrefix}4vs4d4*
⊹ *${usedPrefix}4vs4d5*
⊹ *${usedPrefix}4vs4d6*`
conn.sendMessage(m.chat, { text: teks, mentions: participants.map(a => a.id) }, )
}
    handler.command = /^(menuff|menuff)$/i;
    handler.exp = 50;
handler.fail = null;
export default handler;